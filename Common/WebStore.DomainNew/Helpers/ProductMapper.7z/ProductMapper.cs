﻿using WebStore.DomainNew.Dto;
using WebStore.DomainNew.Entities;

namespace WebStore.DomainNew.Helper
{
    public static class ProductMapper
    {
        public static ProductDto ToDto(this Product p) =>
            new ProductDto
            {
                Id = p.Id,
                Name = p.Name,
                Order = p.Order,
                Price = p.Price,
                ImageUrl = p.ImageUrl,
                // добавим информацию о бренде, если она есть
                Brand = p.BrandId.HasValue ? new BrandDto { Id = p.Brand.Id, Name = p.Brand.Name } : null,
                Section = new SectionDto
                {
                    Id = p.SectionId,
                    Name = p.Section.Name
                }
            };
        public static Product ToProduct(this ProductDto productDto) =>
         new Product
         {
             BrandId = productDto.Brand?.Id,
             SectionId = productDto.Section.Id,
             Name = productDto.Name,
             ImageUrl = productDto.ImageUrl,
             Order = productDto.Order,
             Price = productDto.Price
         };
        public static ProductViewModel ToViewModel(this ProductDto product,IEnumerable<Section> sections,IEnumerable)
    }
}